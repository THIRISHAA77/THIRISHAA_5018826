package com.example.employeemanagementsystem8.projection;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DepartmentDetailProjection {
    private String departmentName;
    private int employeeCount;

    public DepartmentDetailProjection(String departmentName, long employeeCount) {
        this.departmentName = departmentName;
        this.employeeCount = (int) employeeCount;
    }
}
