package com.example.employeemanagementsystem8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem8Application {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystem8Application.class, args);
    }
}
