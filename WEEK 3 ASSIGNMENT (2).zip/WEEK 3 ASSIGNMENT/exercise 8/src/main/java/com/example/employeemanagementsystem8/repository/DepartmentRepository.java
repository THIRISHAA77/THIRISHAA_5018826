package com.example.employeemanagementsystem8.repository;

import com.example.employeemanagementsystem8.entity.Department;
import com.example.employeemanagementsystem8.projection.DepartmentNameProjection;
import com.example.employeemanagementsystem8.projection.DepartmentDetailProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    
    // Interface-based projection
    List<DepartmentNameProjection> findAllBy();

    // Class-based projection
    @Query("SELECT new com.example.employeemanagementsystem8.projection.DepartmentDetailProjection(d.departmentName, COUNT(e)) FROM Department d JOIN d.employees e GROUP BY d.departmentName")
    List<DepartmentDetailProjection> findDepartmentDetails();
}
