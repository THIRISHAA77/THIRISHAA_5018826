package com.example.employeemanagementsystem8.projection;

public interface DepartmentNameProjection {
    String getDepartmentName();
}
