package com.example.employeemanagementsystem8.repository;

import com.example.employeemanagementsystem8.entity.Employee;
import com.example.employeemanagementsystem8.projection.EmployeeNameProjection;
import com.example.employeemanagementsystem8.projection.EmployeeFullNameProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
    // Interface-based projection
    List<EmployeeNameProjection> findAllBy();

    // Class-based projection
    @Query("SELECT new com.example.employeemanagementsystem8.projection.EmployeeFullNameProjection(e.firstName, e.lastName) FROM Employee e")
    List<EmployeeFullNameProjection> findEmployeeFullNames();
}
