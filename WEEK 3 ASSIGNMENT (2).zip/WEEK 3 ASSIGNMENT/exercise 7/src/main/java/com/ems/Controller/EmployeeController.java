package com.ems.Controller;


import com.ems.details.employee.Employee;
import com.ems.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Pagination and Sorting for finding employees by name
    @GetMapping("/search/name")
    public Page<Employee> getEmployeesByName(@RequestParam String name, Pageable pageable) {
        return employeeRepository.findByName(name, pageable);
    }

    // Pagination and Sorting for finding employees by department name
    @GetMapping("/search/department")
    public Page<Employee> getEmployeesByDepartmentName(@RequestParam String departmentName, Pageable pageable) {
        return employeeRepository.findByDepartmentName(departmentName, pageable);
    }

    
}