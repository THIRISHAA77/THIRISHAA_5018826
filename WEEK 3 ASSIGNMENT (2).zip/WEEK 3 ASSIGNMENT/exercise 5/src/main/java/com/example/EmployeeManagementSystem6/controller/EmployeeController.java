package com.example.EmployeeManagementSystem6.controller;

import com.example.EmployeeManagementSystem6.entity.Employee;
import com.example.EmployeeManagementSystem6.repository.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
    
    @Autowired
    private EmployeeRepository employeeRepository;
    
    // Custom query method using method name
    @GetMapping("/byLastName/{lastName}")
    public List<Employee> getEmployeesByLastName(@PathVariable String lastName) {
        return employeeRepository.findByLastName(lastName);
    }
    
    // Custom query method using @Query annotation
    @GetMapping("/byEmail/{email}")
    public List<Employee> getEmployeesByEmail(@PathVariable String email) {
        return employeeRepository.findByEmail(email);
    }
    
    // Named query
    @GetMapping("/byDepartment/{departmentName}")
    public List<Employee> getEmployeesByDepartmentName(@PathVariable String departmentName) {
        return employeeRepository.findByDepartmentName(departmentName);
    }
}
