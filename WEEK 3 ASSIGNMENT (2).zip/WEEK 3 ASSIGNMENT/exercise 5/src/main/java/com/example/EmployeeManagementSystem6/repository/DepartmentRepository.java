package com.example.EmployeeManagementSystem6.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.EmployeeManagementSystem6.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Additional custom queries can be added here if needed
}
