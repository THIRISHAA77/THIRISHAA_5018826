package com.library.repository;

public class BookRepository {
    public void save(String book) {
        System.out.println("Book saved: " + book);
    }
}
