package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Business logic methods
    public void performSomeOperation() {
        // Use bookRepository to perform some operation
        System.out.println("Performing operation with bookRepository: " + bookRepository);
        bookRepository.someRepositoryMethod();
    }
}


