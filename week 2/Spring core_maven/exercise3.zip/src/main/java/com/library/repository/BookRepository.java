package com.library.repository;

public class BookRepository {
    // Repository methods
    public void someRepositoryMethod() {
        // Implementation here
        System.out.println("BookRepository method called");
    }
}
