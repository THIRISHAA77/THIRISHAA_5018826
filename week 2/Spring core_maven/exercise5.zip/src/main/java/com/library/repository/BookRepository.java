package com.library.repository;

public class BookRepository {
    // No implementation needed for this test
}
